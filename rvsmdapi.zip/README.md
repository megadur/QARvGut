# Rest-Api Definitionen zwischen rvSMD und rvGutachten

## rvgutachten-openapi

rvGutachten: Server
rvSMD: Consumer


## rvsmd-openapi

rvSMD: Server
rvGutachten: Consumer

